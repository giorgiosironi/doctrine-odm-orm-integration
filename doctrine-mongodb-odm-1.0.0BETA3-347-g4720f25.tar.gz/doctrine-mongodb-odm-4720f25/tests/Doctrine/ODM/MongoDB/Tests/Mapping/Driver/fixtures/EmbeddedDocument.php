<?php

namespace TestDocuments;

use Doctrine\ODM\MongoDB\Mapping\ClassMetadata;

class EmbeddedDocument
{
    public $name;
}