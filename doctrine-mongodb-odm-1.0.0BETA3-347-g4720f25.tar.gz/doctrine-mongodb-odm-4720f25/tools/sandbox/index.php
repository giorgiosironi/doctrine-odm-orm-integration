<?php

require_once 'config.php';

use Documents\User,
    Documents\Address,
    Documents\Phonenumber,
    Documents\Account;

// Your code here...